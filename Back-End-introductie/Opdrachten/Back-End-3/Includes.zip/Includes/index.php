<?php
require("variables.php");

echo "De fruitsoorten zijn: <br>";
foreach ($fruitsoorten as $fruit) {
    echo $fruit . "<br>";
}
?>
