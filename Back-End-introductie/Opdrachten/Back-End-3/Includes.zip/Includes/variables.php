<?php
$fruitsoorten = array("Appel", "Banaan", "Sinaasappel");
?>
