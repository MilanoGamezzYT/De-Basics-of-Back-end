<!-- jouw HTML voor een Footer komt hier... 
Benoem hier ten minste je naam en de tijd
-->
<footer>
    <p>&copy; 2024, Milan Sebes. Alle rechten voorbehouden.</p>
</footer>
