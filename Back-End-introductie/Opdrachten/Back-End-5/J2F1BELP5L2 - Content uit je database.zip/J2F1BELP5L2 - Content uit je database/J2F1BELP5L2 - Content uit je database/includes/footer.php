<!-- jouw HTML voor een Footer komt hier... 
Benoem hier ten minste je naam en de tijd
-->

<footer>
        <p>&copy; <?php echo date("Y"); ?> Milan Sebes</p>
        <p>Actuele tijd: <?php echo date("H:i:s"); ?></p>
    </footer>
</body>
</html>
